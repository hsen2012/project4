function sginf(){

    var g=document.getElementsByName("gander");

    var ag=document.getElementById("age").value;


    if(fName.value.length < 2 && lName.value.length < 2){
 
        alert("PLEASE WRIGHT YOUR REAL NAME")


    }else if(email.value!=cemail.value){

        alert("please confirm your same email")

    }else if(password.value!=cpassword.value){

        alert("The password not matched")

    }else if( password.value.length < 8 && cpassword.value.length < 8){

        alert("The password less than 8 numbers")

    }else if(g[0].checked==false && g[1].checked==false){

        alert("you have to selected your gander")

        }else if(ag==false){

            alert("please enter your age")

        }else{

            window.open("../page_logn/login.html")

    }

}


