function loginf(){



    var e = document.getElementById("emmilId").value;

    var p = document.getElementById("passId").value;


    if(e==false){


        alert("You have to enter your email")

    }else if(p==false){

        alert("You have to enter your password")

    }else{

        window.open("https://www.facebook.com/groups/thnewbaghdad/?ref=bookmarks")

    }



}