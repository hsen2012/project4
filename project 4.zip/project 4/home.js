function goto(x){

   



    if(x==but1){

window.open("page_sgin/sginup.html")

}else{
    window.open("page_logn/login.html")


}

 }